package com.nscc.w0281673.vidplayer;


import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MediaController;
import android.widget.VideoView;

import java.util.ArrayList;

public class VideoActivity extends AppCompatActivity {
    private DBHelper vidDB;
    EditText rating;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        final Bundle b = getIntent().getExtras();
        rating = (EditText) findViewById(R.id.ratingField);
        Button ratingButton, deleteButton;

        vidDB = new DBHelper(this);
        ArrayList<String> arrList = vidDB.getAllTrailers();
        VideoView mVideoView;
        ratingButton = (Button) findViewById(R.id.ratingButton);
        deleteButton = (Button) findViewById(R.id.deleteButton);

        ratingButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                if(rating.getText().toString()!=null)
                   vidDB.addRating(b.getInt("searchID"), Integer.parseInt(rating.getText().toString()));
                else
                    vidDB.addRating(b.getInt("searchID"), 0);
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                vidDB.deleteVideo(b.getInt("searchID"));
            }
        });
        String videoUrl= "android.resource://" + getPackageName() + "/" + getResources().getIdentifier(arrList.get(b.getInt("searchId")), "raw", getPackageName());
        Uri vidPath=Uri.parse(videoUrl);
        mVideoView = (VideoView) findViewById(R.id.videoView);
        mVideoView.setVideoPath("android.resource://com.nscc.w0281673.vidplayer/raw/cacwtrailer");
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(mVideoView);
        mVideoView.setMediaController(mediaController);
        mVideoView.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_video, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
